<?php

namespace Evernote\Enml\Converter;

interface HtmlConverterInterface
{
    public function convertToHtml($content);
} 