<?php

namespace Evernote\Enml\HtmlCleaner;

interface HtmlCleanerInterface
{
    public function clean($html);
} 