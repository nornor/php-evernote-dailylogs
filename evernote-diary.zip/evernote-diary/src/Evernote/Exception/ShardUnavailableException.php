<?php

namespace Evernote\Exception;

class ShardUnavailableException extends \Exception
{
    
} 