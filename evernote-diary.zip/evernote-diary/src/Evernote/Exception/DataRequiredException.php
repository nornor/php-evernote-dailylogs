<?php

namespace Evernote\Exception;

class DataRequiredException extends \Exception
{

} 