<?php

namespace Evernote\Exception;

class NotFoundSharedNotebookException extends \Exception
{}