<?php

namespace Evernote\Exception;

class NotFoundNoteException extends \Exception
{

} 