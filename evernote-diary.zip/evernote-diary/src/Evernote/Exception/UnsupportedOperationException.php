<?php

namespace Evernote\Exception;

class UnsupportedOperationException  extends \Exception
{
    
} 