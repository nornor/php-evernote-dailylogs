<?php

namespace Evernote\Exception;

class TakenDownException extends \Exception
{
    
} 