<?php

namespace Evernote\Exception;

class EnmlValidationException extends \Exception
{

} 