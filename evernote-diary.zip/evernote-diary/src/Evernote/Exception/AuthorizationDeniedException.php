<?php

namespace Evernote\Exception;

class AuthorizationDeniedException extends \Exception
{
    
} 